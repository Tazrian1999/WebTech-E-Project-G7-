<!DOCTYPE html>  
<html>  
<head>  
<title>INSERT MEDICINES</title>
<link rel="stylesheet" href="style.css">
<style>
.error {color: #FF0000;}
</style>
<script>  
function checkName()
{
    if (document.getElementById("name").value == "") 
    {
		document.getElementById("nameErr").innerHTML = "Medicine Name Required";
		document.getElementById("nameErr").style.color = "red";
		document.getElementById("name").style.borderColor = "red";
	}
	else
	{
		document.getElementById("nameErr").innerHTML = "";
		document.getElementById("name").style.borderColor = "black";
	}
}
function checkPrice()
{
    if (document.getElementById("price").value == "") 
    {
		document.getElementById("priceErr").innerHTML = "Medicine Price Required";
		document.getElementById("priceErr").style.color = "red";
		document.getElementById("price").style.borderColor = "red";
	}
	else
	{
		document.getElementById("priceErr").innerHTML = "";
		document.getElementById("price").style.borderColor = "black";
	}
}
</script>
</head>  
<body class="banner">
<?php 

session_start();

if (isset($_SESSION['name'])){require 'header2.php';}
else{header("location:login.php");}

require 'Controller/storeMedicines.php';

?>

<div class="div">
<fieldset style="width: 50px">
<legend>INSERT NEW MEDICINES</legend>  
               
<form name="form" method="post"> 
  <label for="name">Medicine Name :</label>
  <input type="text" id="name" name="name" onkeyup="checkName()" onblur="checkName()" onclick="checkName()">
  <span class="error" id="nameErr"> <?php echo $nameErr;?></span><hr>

  <label for="price">Medicine Price:</label>
  <input type="text" id="price" name="price" onkeyup="checkPrice()" onblur="checkPrice()" onclick="checkPrice()">
  <span class="error" id="priceErr"> <?php echo $priceErr;?></span><hr>
<input type="submit" name="submit" value="Insert">
<input type="reset" name="reset" value="Reset">
</form>
</fieldset>  
</div>
<?php
echo $error;
echo "<br>";
echo $message;
echo "<br>";
?>
</div> 
<?php require 'footer.php';?>
</body>  
</html>  