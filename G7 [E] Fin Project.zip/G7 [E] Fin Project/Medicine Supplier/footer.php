<!DOCTYPE html>
<html>
<head>
<style></style>
</head>
<body>
<footer style="width=150 ;height=150">

<br>
<br><br><br><br><br><br><br><br>
<hr>
 <h3 style="text-align: center;color:black;background-color:darkgrey; "><?php echo "Copyright © " . date("Y");?></h3>
<hr>
</footer>
</body>
</html>