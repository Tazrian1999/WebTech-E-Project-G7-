<?php 

require_once ('Model/model.php');

function fetchAllMedicines(){
	return showAllMedicine();

$medicines = $data["ID"];

}
