-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2021 at 06:54 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharma_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `MedicineName` varchar(40) NOT NULL,
  `Price` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`MedicineName`, `Price`) VALUES
('Fenadin', '20Taka'),
('Zimax', '50Taka');

-- --------------------------------------------------------

--
-- Table structure for table `prescription_info`
--

CREATE TABLE `prescription_info` (
  `ID` int(40) NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Age` varchar(40) NOT NULL,
  `Medicine` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescription_info`
--

INSERT INTO `prescription_info` (`ID`, `Name`, `Age`, `Medicine`) VALUES
(2, 'Tanzina Azmarin', '23', 'Zimax,Napa'),
(3, 'Tanzina', '12', 'ffff'),
(4, 'Ms jj', '56', 'Gnnn'),
(6, 'K K', '24', 'cmos');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `Name` varchar(40) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Password` varchar(40) NOT NULL,
  `Gender` varchar(40) NOT NULL,
  `DateOfBirth` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`Name`, `Email`, `Password`, `Gender`, `DateOfBirth`) VALUES
('Azmarin Sharna', 'a@gmail.com', 'aaaaaaaa@', 'Female', '2021-08-20'),
('Ms Tanzina', 'a@gamil.com', 'nnnnnnn@', 'Female', '2021-08-09'),
('Ms Tanziiii', 'tan@gmail.com', 'abcccc12@', 'Female', '2021-08-03'),
('Ms Tanziiii', 'tan@gmail.com', 'abcccc12@', 'Female', '2021-08-03'),
('json roy', 'json@kk.com', '@12345', 'Male', '2021-07-25'),
('Ms jhb', 'gg@gmai.com', 'ggg111@@', 'Female', '2021-07-26'),
('Mr jk', 'jk@g.com', 'jjjjjjj@', 'Male', '2021-08-17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prescription_info`
--
ALTER TABLE `prescription_info`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prescription_info`
--
ALTER TABLE `prescription_info`
  MODIFY `ID` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
